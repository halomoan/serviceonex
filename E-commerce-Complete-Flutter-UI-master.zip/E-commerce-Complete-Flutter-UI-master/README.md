# E-Commerce Complate Flutter UI Staring code

### Note that: This is not complete yet

## [Watch it on YouTube](https://youtu.be/YEJPg2jwzI8)

**Packages we are using:**

- flutter_svg: [link](https://pub.dev/packages/flutter_svg)

Complete responsive e-commerce app UI by using flutter.

### Previews of Final UI

![Preview](/intro.gif)
![Preview](/1.png)
![Preview](2.png)
![Preview](3.png)
![Preview](4.png)
![Preview](5.png)
